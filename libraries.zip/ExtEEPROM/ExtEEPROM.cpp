/*
  ExtEEPROM.cpp - A library for 24LCxxx and 24Cxxx series I2C EEPROMs
  Based on the I2C EEPROM code found at http://playground.arduino.cc/Code/I2CEEPROM
  Put together by Kerem Izgol
*/

#include "Arduino.h"
#include "Wire.h"
#include "ExtEEPROM.h"

ExtEEPROM::ExtEEPROM(int deviceaddress)
{
  Wire.begin();
  Wire.beginTransmission(deviceaddress);
  _deviceaddress = deviceaddress;
}

void ExtEEPROM::write(unsigned int eeaddress, byte data )
{
  Wire.beginTransmission(_deviceaddress);
  Wire.write((int)(eeaddress >> 8));   // MSB
  Wire.write((int)(eeaddress & 0xFF)); // LSB
  Wire.write(data);
  Wire.endTransmission();
  delay(5);
}

byte ExtEEPROM::read(unsigned int eeaddress )
{
  Wire.beginTransmission(_deviceaddress);
  byte rdata = 0xFF;
  Wire.write((int)(eeaddress >> 8));   // MSB
  Wire.write((int)(eeaddress & 0xFF)); // LSB
  Wire.endTransmission();
  Wire.requestFrom(_deviceaddress, 1);
  if (Wire.available()) rdata = Wire.read();
  return rdata;
}
