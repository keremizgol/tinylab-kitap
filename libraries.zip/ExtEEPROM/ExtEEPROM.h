/*
  ExtEEPROM.h - A library for 24LCxxx and 24Cxxx series I2C EEPROMs
  Based on the I2C EEPROM code found at http://playground.arduino.cc/Code/I2CEEPROM
  Put together by Kerem Izgol
*/

#ifndef ExtEEPROM_h
#define ExtEEPROM_h

#include "Arduino.h"
#include "Wire.h"

class ExtEEPROM
{
  public:
    ExtEEPROM(int deviceaddress);
    void write(unsigned int eeaddress, byte data );
    byte read(unsigned int eeaddress );
  private:
    int _deviceaddress;
};

#endif
